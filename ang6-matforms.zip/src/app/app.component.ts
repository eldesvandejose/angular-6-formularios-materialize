import { Component, OnInit } from '@angular/core';

declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'a6mf-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  public $estaciones = {
    '01' : 'Primavera',
    '02' : 'Verano',
    '03' : 'Otoño',
    '04' : 'Invierno'
  };

  public __construct() { }

  ngOnInit() {
    $(document).ready(function () {
      $('select').formSelect();
      $('.datepicker').datepicker({
        format: 'dd-mm-yyyy',
        i18n: {
          cancel: 'Cancelar',
          clear: 'Borrar',
          done: 'Hecho',
          months: [
            'Enero',
            'Febrero',
            'Marzo',
            'Abril',
            'Mayo',
            'Junio',
            'Julio',
            'Agosto',
            'Septiembre',
            'Octubre',
            'Noviembre',
            'Diciembre'
          ],
          monthsShort: [
            'Ene',
            'Feb',
            'Mar',
            'Abr',
            'May',
            'Jun',
            'Jul',
            'Ago',
            'Sep',
            'Oct',
            'Nov',
            'Dic'
          ],
          weekdays: [
            'Domingo',
            'Lunes',
            'Martes',
            'Miércoles',
            'Jueves',
            'Viernes',
            'Sábado'
          ],
          weekdaysShort: [
            'Dom',
            'Lun',
            'Mar',
            'Mié',
            'Jue',
            'Vie',
            'Sáb'
          ],
          weekdaysAbbrev: ['D', 'L', 'M', 'X', 'J', 'V', 'S']
        },
        firstDay: 1
      });
    });
  }
}
